/**
 *
 * This file was generated with Adobe XD React Exporter
 * Exporter for Adobe XD is written by: Johannes Pichler <j.pichler@webpixels.at>
 *
 **/

import React from "react";
import Svg, { Defs, G, Rect, Text, TSpan } from "react-native-svg";
/* Adobe XD React Exporter has dropped some elements not supported by react-native-svg: style */

const ButtonComponent = () => (
  <Svg width={144} height={48} viewBox="0 0 144 48">
    <Defs />
    <G transform="translate(141 403)">
      <G transform="translate(-141 -403)">
        <Rect className="a" width={144} height={48} rx={24} />
        <Text className="b" transform="translate(72 30)">
          <TSpan x={-26.352} y={0}>
            {"Sign in"}
          </TSpan>
        </Text>
      </G>
    </G>
  </Svg>
);

export default ButtonComponent;
